---
name: build-lifetime-hosting-html-site
description: Build or rebuild a complete static lifetime-hosting sales website using only semantic HTML, CSS, and vanilla JavaScript. Use when the user asks for a lifetime hosting website, a five-page hosting site, hosting pricing cards or comparison tables, an SEO-ready static HTML website, or a site based on LifetimeHosting.tech plans. Produces Home, About Us, Contact Us, Privacy Policy, Terms and Conditions, sitemap.xml, and robots.txt with responsive UI, accessible navigation, plan CTAs, structured data, metadata, and deterministic validation.
---

# Build Lifetime Hosting HTML Site

Create a production-oriented static website, not a mockup. Write the files into the user's requested output directory and preserve unrelated files.

## Required references

Read these files before creating or changing the website:

- `references/site-specification.md` for required pages, homepage order, content, UI, and pricing-source rules.
- `references/seo-and-schema.md` for metadata, canonical, robots, sitemap, and structured-data requirements.
- `references/acceptance-checklist.md` before validation and delivery.

## Workflow

### 1. Resolve inputs

Determine the output directory, public site URL, site/brand name, contact details, and any color or logo requirements from the request and current project.

- Inspect existing project files before editing.
- Ask one concise question only when the public URL or brand is missing and accurate canonicals, sitemap URLs, or page copy cannot be produced without it.
- If the user explicitly requests autonomous output without those inputs, use conspicuous placeholders such as `https://example.com` and `hello@example.com`, then list every placeholder at handoff.
- Never invent customer counts, guarantees, accreditations, uptime history, ratings, or legal/business details.

### 2. Refresh plan facts

Retrieve current public plan information from `https://lifetimehosting.tech/` before writing pricing content when network access is available.

- Match plan name, base one-time price, website allowance, storage, bandwidth, databases, email accounts, compute limits, backups, migration, SSL, server stack, and support.
- Use the fixed CTA mapping in `references/site-specification.md`; do not replace these links with scraped checkout links.
- Prefer stable base prices. Do not publish a coupon, countdown, or temporary promotional price unless the user explicitly requests it and the promotion is verified as current.
- If retrieval fails, use the dated fallback snapshot in `references/site-specification.md`, state that fallback data was used, and recommend verification before launch.

### 3. Build the file set

Create exactly this baseline structure unless the user asks for different clean URLs:

```text
site-root/
├── index.html
├── about.html
├── contact.html
├── privacy-policy.html
├── terms-and-conditions.html
├── assets/
│   ├── css/styles.css
│   └── js/main.js
├── robots.txt
└── sitemap.xml
```

Use only HTML5, CSS, and vanilla JavaScript. Do not add a framework, package manager, build step, remote UI library, icon font, analytics script, cookie tracker, or third-party form processor unless explicitly requested.

### 4. Implement shared navigation

Use the same complete header navigation on every page: Home, About Us, Contact Us, Privacy Policy, and Terms and Conditions.

- Add a skip link, logo/brand home link, semantic `<nav aria-label="Primary">`, keyboard-accessible mobile menu, visible focus states, and current-page indication.
- Make the footer consistent and include the complete legal navigation.
- Use root-relative links for a root-deployed site or document the chosen relative-link strategy.

### 5. Build the homepage in strict order

Follow this section sequence:

1. Hero with one `<h1>`, short value proposition, supporting details, and pricing CTA.
2. Trust badges immediately below the hero.
3. A natural hosting overview of about 100 words.
4. Three pricing cards: Lifetime Launch, Lifetime Scale, and Lifetime Prime.
5. A responsive comparison table containing all three packages.
6. Feature explanations with a relevant inline SVG icon for each feature.
7. Common lifetime-hosting FAQs.
8. Optional closing CTA followed by the footer.

Give each required section the stable IDs defined in the site specification so the validator can confirm order. Use inline SVG icons with accessible treatment; do not use emoji as primary feature icons.

### 6. Build supporting pages

- About Us: mission, audience, service approach, and clear hosting scope without fabricated company history.
- Contact Us: accessible contact details and form markup. A static form must not pretend to submit successfully; connect it only to a user-provided endpoint or label it clearly as a front-end form.
- Privacy Policy: describe only data flows actually present in the static site. Do not claim use of analytics, cookies, or processors that were not added.
- Terms and Conditions: cover informational site use, plan/order links, pricing changes, third-party services, acceptable use, and limitation language using editable, plain-English copy. Mark details requiring legal review.

Do not present generated policy text as legal advice or guaranteed jurisdictional compliance.

### 7. Apply UI and performance rules

- Use a clean, sharp-edged visual system with consistent spacing, restrained shadows, high contrast, and no glassmorphism overload.
- Make layouts responsive from 320px upward. Prevent horizontal overflow, clipped controls, and unreadable tables.
- Use CSS Grid/Flexbox, system fonts or locally supplied fonts, and reusable custom properties.
- Keep interaction transitions at or below 200ms. Do not add parallax, autoplay, infinite animation, cursor effects, scroll hijacking, or animation that delays content.
- Respect `prefers-reduced-motion` and retain full functionality without JavaScript.
- Keep JavaScript limited to progressive enhancements such as the mobile menu and FAQ disclosure behavior.

### 8. Apply SEO and structured data

Follow `references/seo-and-schema.md` on every page. Titles and descriptions must be unique and match visible page content. Canonical and sitemap URLs must use the final public origin.

Implement a five-star rating scale only with truthful, verifiable rating data. `bestRating: "5"` defines the scale; it does not justify inventing a perfect `ratingValue`. If a valid rating value and count cannot be verified, omit `aggregateRating`, keep the other Organization/WebSite/Service schema, and report the missing evidence.

### 9. Validate and fix

Run:

```bash
python3 <skill-directory>/scripts/validate_site.py <site-root>
```

Then:

- Fix every error.
- Review warnings and resolve all launch-blocking placeholders or stale facts.
- Open the pages locally when browser or screenshot tooling is available; inspect desktop and mobile widths.
- Check all local links, CTA destinations, heading hierarchy, keyboard navigation, focus visibility, mobile menu behavior, table overflow, and FAQ behavior.
- Run the validator again after fixes.

## Delivery

Return the output directory, a short file summary, validation result, and any remaining placeholders or facts that require owner/legal verification. Do not claim the site is ready to publish while the validator reports errors.
