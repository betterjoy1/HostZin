# SEO and structured-data requirements

## Every HTML page

- Use `<!doctype html>` and `<html lang="en">` unless another language is requested.
- Include one clear `<h1>`, logical heading order, and semantic landmarks: `<header>`, `<nav>`, `<main>`, sections as appropriate, and `<footer>`.
- Add a unique, natural `<title>` of roughly 30–60 characters.
- Add a unique `<meta name="description">` of roughly 120–160 characters.
- Add `<meta name="robots" content="index, follow">` for public production pages.
- Add an absolute self-referencing `<link rel="canonical">` using HTTPS and the final public URL.
- Add viewport, charset, and useful social sharing metadata when accurate assets/URLs exist.
- Use descriptive links, useful image alt text, explicit form labels, and no keyword stuffing.

Do not place a `robots` meta tag in `robots.txt`; these are separate controls. Do not canonicalize all pages to the homepage.

## Structured data

Use valid JSON-LD in `<script type="application/ld+json">`. Prefer a single `@graph` containing only entities supported by visible content:

- `Organization` for the operator and contact identity.
- `WebSite` for the site name and root URL.
- `Service` or `Product`/`OfferCatalog` for lifetime hosting plans and one-time offers.
- `FAQPage` on the homepage only when every question and answer is visible to users.
- `BreadcrumbList` on supporting pages when visible breadcrumbs are present.

Use absolute URLs and stable `@id` values. Keep plan prices, currencies, availability, URLs, and names synchronized with visible pricing cards.

### Five-star scale

When verified rating evidence exists, an `aggregateRating` can use:

```json
{
  "@type": "AggregateRating",
  "ratingValue": "4.7",
  "bestRating": "5",
  "worstRating": "1",
  "ratingCount": "VERIFIED_COUNT"
}
```

`bestRating: "5"` means a five-star scale. It does not mean the rating is 5. Never invent `ratingValue`, `ratingCount`, or `reviewCount`. The plan source displayed a 4.7/5 summary when checked on 2026-08-19, but the count must still be verified at generation time. If complete evidence is unavailable, omit `aggregateRating` and mention this at handoff.

## `robots.txt`

Include at minimum:

```text
User-agent: *
Allow: /
Sitemap: https://YOUR-DOMAIN.example/sitemap.xml
```

Replace the placeholder with the final origin. Do not block CSS or JavaScript needed to render pages.

## `sitemap.xml`

Create a valid XML sitemap containing absolute canonical URLs for all five public pages. Add accurate `<lastmod>` values only when known; omit fabricated `changefreq` and `priority` values.

## Launch checks

- Canonical URLs, sitemap URLs, navigation paths, and deployment paths agree.
- No page uses `noindex` unintentionally.
- Metadata is unique, grammatically clean, and consistent with the page.
- JSON-LD parses as JSON and mirrors visible claims.
- Rating markup is omitted unless verified.
