# Acceptance checklist

## Files

- Five required HTML pages exist.
- `assets/css/styles.css` and `assets/js/main.js` are local and load correctly.
- `robots.txt` and `sitemap.xml` exist and use the final public origin.
- No build tooling or framework is required.

## Navigation and semantics

- Every page has the complete five-page header navigation and consistent footer links.
- Every page has one `<h1>`, a useful title, description, robots meta tag, and self-canonical.
- Skip link, focus states, labels, landmarks, and keyboard behavior are usable.
- Mobile menu remains usable without trapping focus or hiding content.

## Homepage

- Required section IDs appear in the prescribed order.
- Hero includes a pricing CTA; trust badges follow immediately.
- Hosting overview is 90–120 words.
- Three pricing cards use current plan data and exact fixed CTA URLs.
- Comparison table includes all plans and remains usable on small screens.
- Concrete icon-led feature section sits after comparison and before FAQs.
- FAQs are visible, accurate, and represented by FAQ schema only if marked up on-page.

## UI and performance

- Layout works at 320px, 768px, and desktop widths without horizontal page overflow.
- No animation delays content; transitions are subtle and reduced-motion safe.
- No remote framework, icon font, or unnecessary dependency was added.
- Images, if any, have dimensions and appropriate alt text; decorative SVGs are hidden from assistive technology.

## Facts and compliance

- Pricing was refreshed from the live source or fallback use is disclosed.
- No temporary coupon or countdown is presented as permanent.
- “Lifetime” limitations and separately renewing domains/add-ons are clear.
- No fabricated testimonials, ratings, certifications, or guarantees appear.
- Five-star scale schema uses verified values and count, or aggregate rating is omitted.
- Privacy and terms text matches actual site behavior and is marked for owner/legal review where necessary.

## Final verification

- Run `scripts/validate_site.py` and fix all errors.
- Test every internal link and all three external CTAs.
- Visually inspect homepage and at least one supporting page on desktop and mobile.
- Report remaining placeholders and launch decisions to the user.
