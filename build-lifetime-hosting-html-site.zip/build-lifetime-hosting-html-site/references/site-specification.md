# Site specification

## Pages and paths

| Page | File | Required navigation label |
| --- | --- | --- |
| Home | `index.html` | Home |
| About Us | `about.html` | About Us |
| Contact Us | `contact.html` | Contact Us |
| Privacy Policy | `privacy-policy.html` | Privacy Policy |
| Terms and Conditions | `terms-and-conditions.html` | Terms and Conditions |

Use the complete five-link header navigation on every page.

## Homepage section contract

Use these IDs in this exact order:

1. `hero`
2. `trust`
3. `hosting-overview`
4. `pricing`
5. `comparison`
6. `features`
7. `faq`

The hosting overview should be approximately 100 words (90–120 acceptable), helpful, and written as sales-page copy rather than a blog introduction.

The comparison table must compare at least price, websites, NVMe storage, monthly bandwidth, databases, email accounts, CPU/RAM, backups, migration, SSL/server, and support. Add a caption and responsive wrapper.

Feature explanations belong between comparison and FAQs. Explain concrete features—NVMe storage, LiteSpeed, SSL, cPanel, backups, migration, email, support—with a relevant inline SVG icon, short heading, and practical benefit.

FAQs should cover the meaning of “lifetime,” recurring base-hosting fees, domain renewal, migrations, backups, upgrades/resources, email accounts, refund policy, and support. Keep answers consistent with verified source facts.

## Fixed CTA mapping

| Plan | CTA URL |
| --- | --- |
| Lifetime Launch | `https://lifetimehosting.tech/register-domain.html?plan=launch` |
| Lifetime Scale | `https://lifetimehosting.tech/register-domain.html?plan=scale` |
| Lifetime Prime | `https://lifetimehosting.tech/register-domain.html?plan=prime` |

Use descriptive labels such as “Choose Lifetime Scale.” External CTAs must be ordinary accessible links and must not open new tabs unless the user requests that behavior.

## Pricing fallback snapshot

Source: `https://lifetimehosting.tech/`  
Verified: 2026-08-19  
Use only when live retrieval fails, and disclose use of the snapshot at handoff.

| Fact | Launch | Scale | Prime |
| --- | --- | --- | --- |
| Base one-time price | $99 | $249 | $499 |
| Websites | 1 | Up to 5 | Up to 15 |
| NVMe storage | 1 GB | 15 GB | 40 GB |
| Monthly bandwidth | 15 GB | 150 GB | 400 GB |
| Databases | 5 | 15 | 30 |
| Email accounts | 5 | 25 | 75 |
| Subdomains | 3 | 10 | 30 |
| Domain aliases | 2 | 5 | 15 |
| CPU / RAM / entry processes | 1 vCPU / 1 GB / 10 | 2 vCPU / 2 GB / 20 | 3 vCPU / 3 GB / 30 |
| Inodes | 100,000 | 300,000 | 500,000 |
| Backups | Weekly | Weekly | Weekly |
| Migration | 1 standard site | Up to 5 sites | Up to 10 sites |
| Shared inclusions | Free SSL, LiteSpeed, WordPress optimization, PHP Selector, 200+ auto-install scripts, ticket support | Same | Same |

Do not treat domain registration, premium licenses, managed services, dedicated IPs, upgrades, or optional add-ons as included lifetime services unless the live source explicitly says otherwise.

## Trust and claims

Trust badges may describe verified inclusions such as free SSL, one-time base hosting payment, weekly backups, cPanel, support, migration, or the current refund window. Do not invent certifications or use security/payment logos without permission.

Use “uptime target” rather than an absolute uptime guarantee when that is what the source publishes. Explain that “lifetime” means the lifetime of the provider’s Lifetime Hosting service subject to plan limits, policies, and activity requirements—not a person’s biological lifetime.
