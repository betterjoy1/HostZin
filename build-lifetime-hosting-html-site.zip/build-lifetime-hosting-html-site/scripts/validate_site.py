#!/usr/bin/env python3
"""Validate the static lifetime-hosting website contract using the Python stdlib."""

from __future__ import annotations

import argparse
import json
import re
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse


PAGES = {
    "index.html": "Home",
    "about.html": "About Us",
    "contact.html": "Contact Us",
    "privacy-policy.html": "Privacy Policy",
    "terms-and-conditions.html": "Terms and Conditions",
}
ASSETS = ("assets/css/styles.css", "assets/js/main.js", "robots.txt", "sitemap.xml")
CTA_URLS = (
    "https://lifetimehosting.tech/register-domain.html?plan=launch",
    "https://lifetimehosting.tech/register-domain.html?plan=scale",
    "https://lifetimehosting.tech/register-domain.html?plan=prime",
)
HOME_SECTIONS = ("hero", "trust", "hosting-overview", "pricing", "comparison", "features", "faq")


class PageParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tags: list[str] = []
        self.ids: list[str] = []
        self.h1_count = 0
        self.title = ""
        self._in_title = False
        self.metas: list[dict[str, str]] = []
        self.links: list[dict[str, str]] = []
        self.scripts: list[tuple[dict[str, str], str]] = []
        self._script_attrs: dict[str, str] | None = None
        self._script_text: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        data = {key.lower(): value or "" for key, value in attrs}
        tag = tag.lower()
        self.tags.append(tag)
        if data.get("id"):
            self.ids.append(data["id"])
        if tag == "h1":
            self.h1_count += 1
        elif tag == "title":
            self._in_title = True
        elif tag == "meta":
            self.metas.append(data)
        elif tag in {"a", "link"}:
            self.links.append({"tag": tag, **data})
        elif tag == "script":
            self._script_attrs = data
            self._script_text = []

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag == "title":
            self._in_title = False
        elif tag == "script" and self._script_attrs is not None:
            self.scripts.append((self._script_attrs, "".join(self._script_text).strip()))
            self._script_attrs = None
            self._script_text = []

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title += data
        if self._script_attrs is not None:
            self._script_text.append(data)


def meta_content(parser: PageParser, name: str) -> str:
    for item in parser.metas:
        if item.get("name", "").lower() == name:
            return item.get("content", "").strip()
    return ""


def canonical(parser: PageParser) -> str:
    for item in parser.links:
        if item.get("tag") == "link" and "canonical" in item.get("rel", "").lower().split():
            return item.get("href", "").strip()
    return ""


def walk_json(value):
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from walk_json(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_json(child)


def validate(root: Path) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    parsers: dict[str, PageParser] = {}

    for relative in (*PAGES, *ASSETS):
        if not (root / relative).is_file():
            errors.append(f"Missing required file: {relative}")

    for filename in PAGES:
        path = root / filename
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        parser = PageParser()
        parser.feed(text)
        parsers[filename] = parser

        lowered = text.lower()
        if "<!doctype html" not in lowered:
            errors.append(f"{filename}: missing HTML5 doctype")
        for landmark in ("header", "nav", "main", "footer"):
            if landmark not in parser.tags:
                errors.append(f"{filename}: missing <{landmark}> landmark")
        if parser.h1_count != 1:
            errors.append(f"{filename}: expected exactly one h1; found {parser.h1_count}")
        title = " ".join(parser.title.split())
        if not title:
            errors.append(f"{filename}: missing title")
        elif not 30 <= len(title) <= 60:
            warnings.append(f"{filename}: title length is {len(title)} characters (target 30–60)")
        description = meta_content(parser, "description")
        if not description:
            errors.append(f"{filename}: missing meta description")
        elif not 120 <= len(description) <= 160:
            warnings.append(f"{filename}: meta description length is {len(description)} characters (target 120–160)")
        robots = meta_content(parser, "robots").lower().replace(" ", "")
        if "index" not in robots or "follow" not in robots:
            errors.append(f"{filename}: robots meta must include index, follow")
        canon = canonical(parser)
        if not canon:
            errors.append(f"{filename}: missing canonical link")
        elif urlparse(canon).scheme != "https" or not urlparse(canon).netloc:
            errors.append(f"{filename}: canonical must be an absolute HTTPS URL")
        elif "example.com" in canon:
            warnings.append(f"{filename}: canonical still uses example.com placeholder")

        hrefs = {item.get("href", "").split("#", 1)[0] for item in parser.links if item.get("tag") == "a"}
        for required_page in PAGES:
            if required_page not in hrefs and f"/{required_page}" not in hrefs and not (
                required_page == "index.html" and "/" in hrefs
            ):
                errors.append(f"{filename}: navigation does not link to {required_page}")

    home_path = root / "index.html"
    if home_path.is_file():
        text = home_path.read_text(encoding="utf-8")
        parser = parsers["index.html"]
        positions = [parser.ids.index(section) if section in parser.ids else -1 for section in HOME_SECTIONS]
        for section, position in zip(HOME_SECTIONS, positions):
            if position < 0:
                errors.append(f"index.html: missing required section id #{section}")
        if all(position >= 0 for position in positions) and positions != sorted(positions):
            errors.append("index.html: required homepage sections are out of order")
        for plan in ("Lifetime Launch", "Lifetime Scale", "Lifetime Prime"):
            if plan.lower() not in text.lower():
                errors.append(f"index.html: missing plan name {plan}")
        for url in CTA_URLS:
            if url not in text:
                errors.append(f"index.html: missing exact CTA URL {url}")
        overview_match = re.search(
            r'<(?:section|div)[^>]+id=["\']hosting-overview["\'][^>]*>(.*?)</(?:section|div)>',
            text,
            flags=re.IGNORECASE | re.DOTALL,
        )
        if overview_match:
            words = re.findall(r"\b[\w’'-]+\b", re.sub(r"<[^>]+>", " ", overview_match.group(1)))
            if not 90 <= len(words) <= 120:
                warnings.append(f"index.html: hosting overview is {len(words)} words (target 90–120)")

        json_objects = []
        for attrs, body in parser.scripts:
            if attrs.get("type", "").lower() != "application/ld+json":
                continue
            try:
                json_objects.append(json.loads(body))
            except json.JSONDecodeError as exc:
                errors.append(f"index.html: invalid JSON-LD ({exc.msg})")
        if not json_objects:
            errors.append("index.html: missing JSON-LD structured data")
        else:
            types = {
                node.get("@type")
                for obj in json_objects
                for node in walk_json(obj)
                if isinstance(node, dict) and isinstance(node.get("@type"), str)
            }
            if not ({"Organization", "WebSite"} & types):
                errors.append("index.html: JSON-LD should include Organization or WebSite")
            rating_nodes = [
                node for obj in json_objects for node in walk_json(obj)
                if isinstance(node, dict) and node.get("@type") == "AggregateRating"
            ]
            for rating in rating_nodes:
                if str(rating.get("bestRating")) != "5":
                    errors.append("index.html: AggregateRating must define a five-star bestRating of 5")
                if not rating.get("ratingValue") or not (rating.get("ratingCount") or rating.get("reviewCount")):
                    errors.append("index.html: AggregateRating requires verified ratingValue and rating/review count")
            if not rating_nodes:
                warnings.append("index.html: aggregate rating omitted; add only when rating evidence is verified")

    robots_path = root / "robots.txt"
    if robots_path.is_file():
        robots = robots_path.read_text(encoding="utf-8")
        if not re.search(r"(?im)^\s*user-agent\s*:\s*\*", robots):
            errors.append("robots.txt: missing User-agent: *")
        sitemap_match = re.search(r"(?im)^\s*sitemap\s*:\s*(\S+)", robots)
        if not sitemap_match:
            errors.append("robots.txt: missing absolute Sitemap directive")
        elif urlparse(sitemap_match.group(1)).scheme != "https":
            errors.append("robots.txt: Sitemap URL must use HTTPS")

    sitemap_path = root / "sitemap.xml"
    if sitemap_path.is_file():
        sitemap = sitemap_path.read_text(encoding="utf-8")
        for filename in PAGES:
            suffix = "/" if filename == "index.html" else f"/{filename}"
            if suffix not in sitemap:
                errors.append(f"sitemap.xml: missing URL ending in {suffix}")
        if "example.com" in sitemap:
            warnings.append("sitemap.xml: still uses example.com placeholder")

    return errors, warnings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("site_root", type=Path, help="Path containing index.html")
    args = parser.parse_args()
    root = args.site_root.expanduser().resolve()
    if not root.is_dir():
        print(f"ERROR: site root is not a directory: {root}")
        return 2

    errors, warnings = validate(root)
    for item in errors:
        print(f"ERROR: {item}")
    for item in warnings:
        print(f"WARN: {item}")
    print(f"Summary: {len(errors)} error(s), {len(warnings)} warning(s)")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
